# skin.DeepBlue
 Custom Kodi Skin (theme) with ocean blue theme. Based off the blue interface from DirecTV boxes (2006-2012) [a popular satellite TV provider in the United States]
 https://youtu.be/8Nko1Uv-Hio
 
 Want to support me? Please consider [Buying me a coffee ☕](https://www.buymeacoffee.com/UVGrade)
 shoot me any suggestions, new Kodi skins to work on, or other feedback at info@uvgrade.com
